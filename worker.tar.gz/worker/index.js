// CF Workers 克隆站点代理
// 单个 Worker 处理所有克隆站点

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    
    // 从 hostname 提取站点标识: 45177-vip.clone.yourdomain.com → 45177-vip
    const site = url.hostname.split('.')[0];
    
    // 1. API 请求 → KV
    if (url.pathname.startsWith('/hall/api/')) {
      const key = `${site}:${url.pathname}`;
      const data = await env.KV.get(key);
      
      if (data) {
        return new Response(data, {
          headers: {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*'
          }
        });
      }
    }
    
    // 2. 静态资源 → R2
    const r2Key = `${site}${url.pathname === '/' ? '/index.html' : url.pathname}`;
    const obj = await env.R2.get(r2Key);
    
    if (obj) {
      const headers = new Headers();
      obj.writeHttpMetadata(headers);
      headers.set('etag', obj.httpEtag);
      headers.set('Access-Control-Allow-Origin', '*');
      
      return new Response(obj.body, { headers });
    }
    
    // 3. 404
    return new Response('Not Found', { status: 404 });
  }
};
